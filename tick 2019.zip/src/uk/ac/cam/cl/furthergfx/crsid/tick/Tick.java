package uk.ac.cam.cl.furthergfx.crsid.tick;

public class Tick {

  public static void main(String[] args) {
    TickApp app = new TickApp();

    app.init();
    app.run();
    app.shutdown();
  }
}
